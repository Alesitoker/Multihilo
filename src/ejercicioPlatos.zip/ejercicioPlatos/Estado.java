package ejercicioPlatos;

public enum Estado {
    SUCIO, FREGADO, SECO, GUARGADO
}
