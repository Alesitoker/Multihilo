package ejercicioPlatos;

import java.util.concurrent.TimeUnit;

public class Fregador implements Runnable {
    PilaDePlatos platosSucios;
    PilaDePlatos platosFregados;

    public Fregador(PilaDePlatos platosSucios, PilaDePlatos platosFregados) {
        this.platosSucios = platosSucios;
        this.platosFregados = platosFregados;
    }

    @Override
    public void run() {
        Plato plato;
        while (platosSucios.getSize() > 0) {
            plato = platosSucios.removePlato(Thread.currentThread().getName());
            plato.setEstado(Estado.FREGADO);
            platosFregados.addPlato(plato, Thread.currentThread().getName());
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
